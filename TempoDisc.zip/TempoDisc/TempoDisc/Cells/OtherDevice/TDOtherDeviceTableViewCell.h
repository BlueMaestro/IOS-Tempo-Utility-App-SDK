//
//  TDOtherDeviceTableViewCell.h
//  TempoDisc
//
//  Created by Nikola Misic on 3/10/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TDOtherDeviceTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *labelDeviceName;

@end
