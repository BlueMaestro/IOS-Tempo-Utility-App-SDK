//
//  TDOtherDeviceTableViewCell.m
//  TempoDisc
//
//  Created by Nikola Misic on 3/10/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import "TDOtherDeviceTableViewCell.h"

@implementation TDOtherDeviceTableViewCell

- (void)awakeFromNib {
    // Initialization code
	[super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
