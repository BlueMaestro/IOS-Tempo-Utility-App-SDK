//
//  TDDiscDataTableViewCell.m
//  Tempo Utility
//
//  Created by Nikola Misic on 10/10/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import "TDDiscDataTableViewCell.h"

@implementation TDDiscDataTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
