//
//  Reading.h
//  
//
//  Created by Nikola Misic on 2/28/16.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class ReadingType;

NS_ASSUME_NONNULL_BEGIN

@interface Reading : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Reading+CoreDataProperties.h"
