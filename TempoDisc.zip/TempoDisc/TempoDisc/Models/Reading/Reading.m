//
//  Reading.m
//  
//
//  Created by Nikola Misic on 2/28/16.
//
//

#import "Reading.h"
#import "ReadingType.h"

@implementation Reading

// Insert code here to add functionality to your managed object subclass

@end
