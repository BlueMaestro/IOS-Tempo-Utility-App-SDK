//
//  ReadingType.h
//  
//
//  Created by Nikola Misic on 2/28/16.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TempoDevice;

NS_ASSUME_NONNULL_BEGIN

@interface ReadingType : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "ReadingType+CoreDataProperties.h"
