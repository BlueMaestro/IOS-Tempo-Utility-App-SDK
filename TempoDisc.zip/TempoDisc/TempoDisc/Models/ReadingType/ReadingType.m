//
//  ReadingType.m
//  
//
//  Created by Nikola Misic on 2/28/16.
//
//

#import "ReadingType.h"
#import "TempoDevice.h"

@implementation ReadingType

// Insert code here to add functionality to your managed object subclass

@end
