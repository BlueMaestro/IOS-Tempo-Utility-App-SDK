//
//  TDDevicesHistoryListTableViewController.h
//  Tempo Utility
//
//  Created by Nikola Misic on 10/13/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import "TDDeviceListTableViewController.h"

@interface TDDevicesHistoryListTableViewController : TDDeviceListTableViewController

@end
