//
//  DeviceInfoTableViewController.h
//  TempoDisc
//
//  Created by Nikola Misic on 9/21/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceInfoTableViewController : UITableViewController

@property (nonatomic, strong) NSArray *dataSource;

@end
