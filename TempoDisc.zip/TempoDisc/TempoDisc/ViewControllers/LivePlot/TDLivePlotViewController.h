//
//  TDLivePlotViewController.h
//  Tempo Utility
//
//  Created by Nikola Misic on 11/19/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TDBaseDeviceViewController.h"

@interface TDLivePlotViewController : TDBaseDeviceViewController

@end
