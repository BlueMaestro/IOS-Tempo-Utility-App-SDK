//
//  TDHistoryContainerViewController.h
//  TempoDisc
//
//  Created by Nikola Misic on 10/6/16.
//  Copyright © 2016 BlueMaestro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TDDevicesContainerViewController.h"

@interface TDHistoryContainerViewController : TDDevicesContainerViewController

@end
